<?php
  session_start();
if (!isset($_SESSION['userid'])){
    require "../redirect.php";
}else{
    $now=time();
    if ($now > $_SESSION['expire']){
        session_destroy();
        require "../redirect.php"; 
    }else{        
    }
}
?>
<?php             
      $msg="";
      $con = mysqli_connect('localhost','merimeve_event','user@event','merimeve_event') or die(mysqli_error());
      //if submit button is pressed
      if (isset($_POST['btn_login'])){

          $mname        =$_POST['mname'];
          $lname        =$_POST['lname'];
          $gender       =$_POST['gender'];
          $code         =$_POST['code']; 
          $box          =$_POST['box'];
          $town         =$_POST['town'];
          $identity     =$_POST['identity'];
          $phy_address  =$_POST['phy_address'];
          $fcontact     =$_POST['fcontact'];
          $scontact     =$_POST['scontact'];
          $email        =$_POST['email'];
          $b_c_name     =$_POST['b_c_name'];
          $b_c_location =$_POST['b_c_location'];
          $reg_date     =date("Y-m-d");
          $reg_time     =date("h:i:sa");
          $company      =$_SESSION['company'];

  $sql_u = "SELECT * FROM tblcustomers WHERE identity = '$identity' and company='$company' ";
      $results = mysqli_query($con,$sql_u);
        if(mysqli_num_rows($results)>0){
            echo '<script type="text/javascript">'; 
                echo 'alert("The customer is already registered !!!");'; 
                echo 'window.location = "c.php";';
                echo '</script>';
    }else{

          $sql="insert into tblcustomers(fname,mname,lname,gender,code,box,town,identity,phy_address,fcontact,scontact,email,b_c_name,b_c_location,company) VALUES('$fname','$mname','$lname','$gender', '$code', '$box','$town', '$identity', '$phy_address','$fcontact','$scontact','$email','$b_c_name','$b_c_location','$company')";
                  
          if(mysqli_query($con, $sql)){
              echo '<script type="text/javascript">'; 
                echo 'alert("The customer is registered successfully.");'; 
                echo 'window.location = "ocr.php";';
                echo '</script>';
          } else {
            echo '<script type="text/javascript">'; 
            echo 'alert("Error occured during submission.");'; 
            //echo 'window.location = "c.php";';
            echo '</script>';
          }

          mysqli_close($con);
        }
    }
      ?>
<!DOCTYPE html>
<html>
    <?php include('../head_css.php'); ?>
    <!--style type="text/css">
        a{
            color:#000;
        }
        .icon{
            width: 30px;
            padding-right: 10px;
        }
        .iconb{
            width: 30px;
            padding-right: 10px;
        }
        .icon:hover{
            transition: 0.3s;
            /*box-shadow: 2px 0px 20px rgba(0, 0, 0, 0.8);*/
        }
        button{
            background-color: transparent;
            border-style: none;
        }
    </style-->
<link href="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/css/bootstrap4-toggle.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script>
    <body class="skin-black">
        <!-- header logo: style can be found in header.less -->
        <?php 
        include "../connection.php";
        ?>
        <?php include('../header.php'); ?>         
        <div class="wrapper row-offcanvas row-offcanvas-left">
            <!-- Left side column. contains the logo and sidebar -->
            <?php include('../sidebar-left.php'); ?>

            <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                <a href="setting.php" title="Go home"><i class="fa fa-angle-double-left" aria-hidden="true" title="Go home"></i> Back</a>
                </section>
                <!-- Main content -->
                <section class="content">
                <div class="box-body table-responsive">
                    <span style="font-weight:bold;">Role: </span>
                    <?php
                        $squery = mysqli_query($con, "select * from tblroles where id='".$_GET['role']."' ");
                             while($row = mysqli_fetch_array($squery))
                                 {
                                    echo ucwords($row['role']);
                                  }
                                ?>
                    
                                <form method="post">
                                    <?php
$con =  mysqli_connect('localhost', 'merimeve_event', 'user@event', 'merimeve_event') or die("connection failed" . mysqli_error()); 
	if(isset($_POST['update']))
	{
	    $txt_id     = $_GET['role'];
	    $register   = $_POST['register'];
	    $lease      = $_POST['lease'];
	    $return     = $_POST['return'];
	    $inventory  = $_POST['inventory'];
	    $penalty    = $_POST['penalty'];
	    $invoice    = $_POST['invoice'];
	    $report     = $_POST['report'];
	    $project    = $_POST['project'];
	    $user       = $_POST['user'];

	       $query = mysqli_query($con,"UPDATE tblroles SET register = '".$register."',lease = '".$lease."',returning = '".$return."',inventory = '".$inventory."',penalty = '".$penalty."',invoice = '".$invoice."',report = '".$report."',project = '".$project."',user = '".$user."' where id = '".$txt_id."' ");
	    

	    if($query == true){
	        echo '<script type="text/javascript">'; 
            echo 'window.location.href = window.location.href;';
            echo '</script>';
	    }

		if(mysqli_error($con)){
			echo '<script type="text/javascript">'; 
            echo 'alert("No changes made.");'; 
            echo 'window.location = "setting.php";';
            echo '</script>';
		}
	}
?>
                                    <button  style="float:right" class="btn btn-primary" type="submit" name="update" id="update" title="Save">Update</button>
                                    <table id="table" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Activities / Modules</th>
                                                <th>Status</th>
                                                <th>Enable</th>
                                                <th>Disable</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $c=1;
                                            $squery = mysqli_query($con, "select * from tblroles where company='".$_SESSION['company']."' and id='".$_GET['role']."' ORDER BY id DESC");
                                            while($row = mysqli_fetch_array($squery))
                                            {
                                                if($row['register']=='1'){
                                                    $r= '<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['register']== '0'){
                                                    $r='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['lease']=='1'){
                                                    $l='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['lease']=='0'){
                                                    $l='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['returning']=='1'){
                                                    $re='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['returning']=='0'){
                                                    $re='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['inventory']=='1'){
                                                    $i='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['inventory']=='0'){
                                                    $i='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['penalty']=='1'){
                                                    $p='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['penalty']== '0'){
                                                    $p='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['invoice']=='1'){
                                                    $in='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['invoice']=='0'){
                                                    $in='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['report']=='1'){
                                                    $rep='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['report']=='0'){
                                                    $rep='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['project']=='1'){
                                                    $pr='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['project']=='0'){
                                                    $pr='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                
                                                if($row['user']=='1'){
                                                    $u='<span style="color:green"> <i class="fa fa-check" aria-hidden="true"></i>'. " Enabled" .'</span>';
                                                }
                                                if($row['user']=='0'){
                                                    $u='<span style="color:red"> <i class="fa fa-times" aria-hidden="true"></i>'. " Disabled" .'</span>';
                                                }
                                                echo '
                                                <tr>
                                                <td>Customer Registration <input type="checkbox" checked data-toggle="toggle" data-onstyle="outline-success" data-offstyle="outline-danger"></td>
                                                <td>'.$r.'</td>
                                                <td><input type="checkbox" checked data-toggle="toggle" data-onstyle="outline-success" data-offstyle="outline-danger"></td>
                                                <td><input type="radio" id="register" name="register" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Leasing Items</td>
                                                <td>'.$l.'</td>
                                                <td><input type="radio" id="lease" name="lease" value="1"></td>
                                                <td><input type="radio" id="lease" name="lease" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Returning Items</td>
                                                <td>'.$re.'</td>
                                                <td><input type="radio" id="return" name="return" value="1"></td>
                                                <td><input type="radio" id="return" name="return" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Inventory management</td>
                                                <td>'.$i.'</td>
                                                <td><input type="radio" id="inventory" name="inventory" value="1"></td>
                                                <td><input type="radio" id="inventory" name="inventory" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Penalties</td>
                                                <td>'.$p.'</td>
                                                <td><input type="radio" id="penalty" name="penalty" value="1"></td>
                                                <td><input type="radio" id="penalty" name="penalty" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Invoices</td>
                                                <td>'.$in.'</td>
                                                <td><input type="radio" id="invoice" name="invoice" value="1"></td>
                                                <td><input type="radio" id="invoice" name="invoice" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Printing reports</td>
                                                <td>'.$rep.'</td>
                                                <td><input type="radio" id="report" name="report" value="1"></td>
                                                <td><input type="radio" id="report" name="report" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Project management</td>
                                                <td>'.$pr.'</td>
                                                <td><input type="radio" id="project" name="project" value="1"></td>
                                                <td><input type="radio" id="project" name="project" value="0"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Add user accounts</td>
                                                <td>'.$u.'</td>
                                                <td><input type="radio" id="user" name="user" value="1"></td>
                                                <td><input type="radio" id="user" name="user" value="0"></td>
                                                </tr>
                                                ';
                                                include "editRole.php";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                   
                                    <?php include "../deleteModal.php"; ?>

                                    </form>
                                </div><!-- /.box-body -->

            <?php include "../notification.php"; ?>

            <?php include "../addModal.php"; ?>

            <?php include "../addfunction.php"; ?>
            <?php include "editfunction.php"; ?>
            <?php include "deletefunction.php"; ?>

          </section>
				</div>
		
        <?php 
        include "../footer.php"; ?>
<script type="text/javascript">
    $(function() {
        $("#table").dataTable({
           "aoColumnDefs": [ { "bSortable": false, "aTargets": [ 0,5 ] } ],"aaSorting": []
        });
    });
</script>
    </body>
</html>



